<?php
/**
 * This is a global parameters for application.
 *
 * @author kurakste
 * @version $Id$
 * @copyright kurakste, 06 июня, 2018
 * @package default
 */
$GLOBALS['params'] = [
    'host'=>'127.0.0.1', 
    'user'=>'homework',
    'password'=>'akfyem',
    'dbname'=>'homework'
];
