
 <div class="clearfix"></div>
 <form id="contact-form" action="#" method="post">
    <fieldset>
       <legend>Форма обратной связи.</legend>
       <p class="label">Как Вам можно обращаться:</p> 
       <p class="input">
       <input 
       placeholder="Введите ваше имя."
       type="text" 
       name="fname" 
       id="fname" 
       value="" />
       </p>
       <p class="label">Тема:</p> 
       <p class="input">
       <input 
       placeholder="Тема Вашего обрашения."
       type="text" 
       name="ftopic" 
       id="ftopic" 
       value="" />
       </p>
       <p class="label">Ваш e-mail:</p>
       <p class="input">
       <input 
          placeholder="inter_your@mail.com"
          type="email" 
          name="fmail" 
          id="fmail" 
          value="" />
       </p>
       <p class="label"><label for="fmessage">Поделитесь с нами вашими мыслями:</label></p>
       <p class="input"><textarea  
          name="fmessage" 
          id="fmessage" 
          rows="5"
          cols="103"></textarea></p>
       <p><input type="submit" value="Отправить"></p>

    </fieldset>
</form>

