<?php

function dd($var)
{
    var_dump($var);
    die;
}

function de($var)
{
    echo $var;
    die;
}
