<?php
/**
 * Выводит форму регистрации нового пользователя. 
 *
 * PHP version 7
 *
 * @category  App
 * @package   Default
 * @author    kurakste <kurakste@gmail.com>
 * @copyright 2018 kurakste
 * @license   http://www.nowhere.net Nothing
 * @version   GIT:0001
 * @link      noway
 */ 
?>
<div class = "formcontainer">
    <form class='fcenter'action="/add-new-user" method="post">
        <input type="text" name="fmane" id="fname" value="" />
        <input type="password" name="fpassword" id="fpassword" value="" />
    </form>
div>
