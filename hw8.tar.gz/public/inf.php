<?php 
    phpinfo();
