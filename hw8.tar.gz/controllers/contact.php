
<?php
/**
 * Контроллер contact 
 */
function showContactPage() {
    return view('contact');
} 
