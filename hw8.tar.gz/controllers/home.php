<?php
/**
 * Контроллер добмашней страницы магазина 
 */
function showMainPage() {
    return view('home');
} 
