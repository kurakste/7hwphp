#!/usr/bin/env sh

######################################################################
# @author      : kurakste (kurakste@kurakste-book.local)
# @file        : startphpprj
# @created     : суббота июн 09, 2018 12:54:32 MSK
#
# @description : Стартовые насторйки PHP проекта.  
######################################################################
mkdir config assets controllers public public/css public/js public/img view models templates



